{ CLI.Subcommands.Test — registry surface coverage.

  The registry is the single source of truth for a program's command
  surface; Count / Item read iteration is what surface-rendering
  consumers (help printers, the host program's agent-facing reference
  generator) build on. This suite pins the iteration contract —
  registration order, exact objects — in-process. Dispatch behaviour
  (argv parsing, help interception, run-aliasing) lives behind
  ParamStr and is covered by the host program's subprocess tests. }

program CLI.Subcommands.Test;

{$I Shared.inc}

uses
  Classes,
  Process,
  SysUtils,

  CLI.Options,
  CLI.Subcommands,
  TestingPascalLibrary;

type
  TSubcommandRegistrySuite = class(TTestSuite)
  private
    function RunCompletionChild(const ARaisingCallback: Boolean): Integer;
  public
    procedure SetupTests; override;
    procedure TestCountAndItemFollowRegistrationOrder;
    procedure TestFindReturnsTheRegisteredObject;
    procedure TestItemExposesOptionObjects;
    procedure TestItemOutOfRangeRaises;
    procedure TestCompletionCallbackReceivesDispatchMetadata;
    procedure TestCompletionCallbackCannotReplaceDispatchResult;
    procedure TestSharedFlagIsInheritedByExistingAndFutureCommands;
    procedure TestSharedFlagRejectsCommandOptionCollisions;
  end;

var
  CompletionCount : Integer = 0;
  CapturedCompletion : TSubcommandCompletion;

const
  NONZERO_HANDLER_EXIT_CODE = 7;

procedure CaptureCompletion(const ACompletion: TSubcommandCompletion);
begin
  Inc(CompletionCount);
  CapturedCompletion := ACompletion;
end;

procedure RaiseFromCompletion(const ACompletion: TSubcommandCompletion);
begin
  Inc(CompletionCount);
  CapturedCompletion := ACompletion;
  raise Exception.Create('completion callback failed');
end;

function StubHandler(const APositionals: TStringList;
  const AOptions: TOptionArray): Integer;
begin
  Result := 0;
end;

function NonzeroHandler(const APositionals: TStringList;
  const AOptions: TOptionArray): Integer;
begin
  Result := NONZERO_HANDLER_EXIT_CODE;
end;

function BuildRegistry: TSubcommandRegistry;
var
  NoOpts   : TOptionArray;
  BetaOpts : TOptionArray;
begin
  Result := TSubcommandRegistry.Create;
  SetLength(NoOpts, 0);
  SetLength(BetaOpts, 1);
  BetaOpts[0] := TFlagOption.Create('check', 'verify without writing');
  Result.Add(TSubcommand.Create('alpha', 'first summary', '[--none]',
    @StubHandler, NoOpts));
  Result.Add(TSubcommand.Create('beta', 'second summary', '',
    @StubHandler, BetaOpts));
end;

function RunCompletionScenario: Integer;
var
  Registry : TSubcommandRegistry;
  RunExitCode : Integer;
begin
  CompletionCount := 0;
  CapturedCompletion.ElapsedMilliseconds := High(QWord);
  Registry := BuildRegistry;
  try
    Registry.OnCommandCompleted := @CaptureCompletion;
    RunExitCode := Registry.Run('fixture');
    if RunExitCode <> 0 then Exit(1);
    if CompletionCount <> 1 then Exit(2);
    if CapturedCompletion.CommandName <> 'alpha' then Exit(3);
    if CapturedCompletion.ExitCode <> 0 then Exit(4);
    if CapturedCompletion.ElapsedMilliseconds = High(QWord) then Exit(5);
    Result := 0;
  finally
    Registry.Free;
  end;
end;

function RunRaisingCompletionScenario: Integer;
var
  Registry : TSubcommandRegistry;
  RunExitCode : Integer;
begin
  CompletionCount := 0;
  Registry := BuildRegistry;
  try
    Registry.Find('alpha').Handler := @NonzeroHandler;
    Registry.OnCommandCompleted := @RaiseFromCompletion;
    RunExitCode := Registry.Run('fixture');
    if RunExitCode <> NONZERO_HANDLER_EXIT_CODE then Exit(8);
    if CompletionCount <> 1 then Exit(9);
    if CapturedCompletion.CommandName <> 'alpha' then Exit(10);
    if CapturedCompletion.ExitCode <> NONZERO_HANDLER_EXIT_CODE then Exit(11);
    Result := RunExitCode;
  finally
    Registry.Free;
  end;
end;

function TSubcommandRegistrySuite.RunCompletionChild(
  const ARaisingCallback: Boolean): Integer;
var
  ProcessInstance : TProcess;
begin
  ProcessInstance := TProcess.Create(nil);
  try
    ProcessInstance.Executable := ExpandFileName(ParamStr(0));
    ProcessInstance.Parameters.Add('alpha');
    if ARaisingCallback then
      ProcessInstance.Parameters.Add('raise-callback');
    ProcessInstance.Options := [poWaitOnExit];
    ProcessInstance.Execute;
    Result := ProcessInstance.ExitCode;
    if (Result = 0) and (ProcessInstance.ExitStatus <> 0) then
      Result := ProcessInstance.ExitStatus;
  finally
    ProcessInstance.Free;
  end;
end;

procedure TSubcommandRegistrySuite.TestCountAndItemFollowRegistrationOrder;
var
  Registry : TSubcommandRegistry;
begin
  Registry := BuildRegistry;
  try
    Expect<Integer>(Registry.Count).ToBe(2);
    Expect<string>(Registry.Item(0).Name).ToBe('alpha');
    Expect<string>(Registry.Item(0).Summary).ToBe('first summary');
    Expect<string>(Registry.Item(0).UsageArg).ToBe('[--none]');
    Expect<string>(Registry.Item(1).Name).ToBe('beta');
  finally
    Registry.Free;
  end;
end;

procedure TSubcommandRegistrySuite.TestFindReturnsTheRegisteredObject;
var
  Registry : TSubcommandRegistry;
begin
  Registry := BuildRegistry;
  try
    Expect<Boolean>(Registry.Find('beta') = Registry.Item(1)).ToBe(True);
    Expect<Boolean>(Registry.Find('BETA') = Registry.Item(1)).ToBe(True);
    Expect<Boolean>(Registry.Find('missing') = nil).ToBe(True);
  finally
    Registry.Free;
  end;
end;

procedure TSubcommandRegistrySuite.TestItemExposesOptionObjects;
var
  Registry : TSubcommandRegistry;
begin
  Registry := BuildRegistry;
  try
    Expect<Integer>(Length(Registry.Item(0).Options)).ToBe(0);
    Expect<Integer>(Length(Registry.Item(1).Options)).ToBe(1);
    Expect<string>(Registry.Item(1).Options[0].LongName).ToBe('check');
  finally
    Registry.Free;
  end;
end;

procedure TSubcommandRegistrySuite.TestItemOutOfRangeRaises;
var
  Registry : TSubcommandRegistry;
  RaisedBelow, RaisedAbove : Boolean;
begin
  { Production builds disable compiler range checks (Shared.inc), so
    Item carries an explicit bounds guard that must raise instead of
    returning a garbage pointer. }
  Registry := BuildRegistry;
  try
    RaisedBelow := False;
    try
      Registry.Item(-1);
    except
      on EArgumentOutOfRangeException do RaisedBelow := True;
    end;
    RaisedAbove := False;
    try
      Registry.Item(Registry.Count);
    except
      on EArgumentOutOfRangeException do RaisedAbove := True;
    end;
    Expect<Boolean>(RaisedBelow).ToBe(True);
    Expect<Boolean>(RaisedAbove).ToBe(True);
  finally
    Registry.Free;
  end;
end;

procedure TSubcommandRegistrySuite.TestCompletionCallbackReceivesDispatchMetadata;
begin
  Expect<Integer>(RunCompletionChild(False)).ToBe(0);
end;

procedure TSubcommandRegistrySuite.TestCompletionCallbackCannotReplaceDispatchResult;
begin
  Expect<Integer>(RunCompletionChild(True)).ToBe(NONZERO_HANDLER_EXIT_CODE);
end;

procedure TSubcommandRegistrySuite.
  TestSharedFlagIsInheritedByExistingAndFutureCommands;
var
  EmptyOptions: TOptionArray;
  Registry: TSubcommandRegistry;
begin
  SetLength(EmptyOptions, 0);
  Registry := TSubcommandRegistry.Create;
  try
    Registry.Add(TSubcommand.Create('before', 'before', '', nil,
      EmptyOptions));
    Registry.AddSharedFlag('silent', 'Suppress ordinary output');
    SetLength(EmptyOptions, 0);
    Registry.Add(TSubcommand.Create('after', 'after', '', nil,
      EmptyOptions));

    Expect<Integer>(Length(Registry.Find('before').Options)).ToBe(1);
    Expect<Integer>(Length(Registry.Find('after').Options)).ToBe(1);
    Expect<string>(Registry.Find('before').Options[0].LongName).ToBe(
      'silent');
    Expect<string>(Registry.Find('after').Options[0].LongName).ToBe(
      'silent');
    Expect<string>(Registry.Find('before').UsageArg).ToBe('[--silent]');
    Expect<string>(Registry.Find('after').UsageArg).ToBe('[--silent]');
    Expect<Boolean>(Registry.Find('before').Options[0]
      <> Registry.Find('after').Options[0]).ToBe(True);
  finally
    Registry.Free;
  end;
end;

procedure TSubcommandRegistrySuite.
  TestSharedFlagRejectsCommandOptionCollisions;
var
  DuplicateCommand: TSubcommand;
  DuplicateOptions: TOptionArray;
  Raised: Boolean;
  Registry: TSubcommandRegistry;
begin
  SetLength(DuplicateOptions, 1);
  DuplicateOptions[0] := TFlagOption.Create('silent', 'local flag');
  Registry := TSubcommandRegistry.Create;
  try
    Registry.Add(TSubcommand.Create('before', 'before', '', nil,
      DuplicateOptions));
    Raised := False;
    try
      Registry.AddSharedFlag('silent', 'shared flag');
    except
      on EArgumentException do Raised := True;
    end;
    Expect<Boolean>(Raised).ToBe(True);
    Expect<Integer>(Length(Registry.Find('before').Options)).ToBe(1);
  finally
    Registry.Free;
  end;

  Registry := TSubcommandRegistry.Create;
  try
    Registry.AddSharedFlag('silent', 'shared flag');
    SetLength(DuplicateOptions, 1);
    DuplicateOptions[0] := TFlagOption.Create('silent', 'local flag');
    DuplicateCommand := TSubcommand.Create('after', 'after', '', nil,
      DuplicateOptions);
    Raised := False;
    try
      Registry.Add(DuplicateCommand);
    except
      on EArgumentException do Raised := True;
    end;
    Expect<Boolean>(Raised).ToBe(True);
  finally
    if Raised then
    begin
      DuplicateOptions[0].Free;
      DuplicateCommand.Free;
      { Add rejected both objects before taking ownership. }
    end;
    Registry.Free;
  end;
end;

procedure TSubcommandRegistrySuite.SetupTests;
begin
  Test('Count + Item iterate subcommands in registration order',
    TestCountAndItemFollowRegistrationOrder);
  Test('Find resolves case-insensitively to the same object Item returns',
    TestFindReturnsTheRegisteredObject);
  Test('Item exposes each subcommand''s option objects',
    TestItemExposesOptionObjects);
  Test('Item raises EArgumentOutOfRangeException outside 0..Count-1',
    TestItemOutOfRangeRaises);
  Test('completion callback receives resolved command metadata exactly once',
    TestCompletionCallbackReceivesDispatchMetadata);
  Test('completion callback cannot replace the command dispatch result',
    TestCompletionCallbackCannotReplaceDispatchResult);
  Test('shared flags reach existing and future subcommands independently',
    TestSharedFlagIsInheritedByExistingAndFutureCommands);
  Test('shared flags reject existing and future option name collisions',
    TestSharedFlagRejectsCommandOptionCollisions);
end;

begin
  if (ParamCount >= 1) and SameText(ParamStr(1), 'alpha') then
  begin
    if (ParamCount = 2) and SameText(ParamStr(2), 'raise-callback') then
      ExitCode := RunRaisingCompletionScenario
    else
      ExitCode := RunCompletionScenario;
    Exit;
  end;

  TestRunnerProgram.AddSuite(TSubcommandRegistrySuite.Create(
    'CLI.Subcommands: registry iteration'));
  TestRunnerProgram.Run;
  ExitCode := TestResultToExitCode;
end.
