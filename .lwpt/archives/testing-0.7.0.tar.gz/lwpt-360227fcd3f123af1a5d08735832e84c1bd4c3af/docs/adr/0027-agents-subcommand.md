# `lwpt agents` is the tenth subcommand: a self-describing command reference for AI harnesses

The subcommand surface, frozen at nine since [ADR-0019](./0019-add-remove-subcommands.md) ([Hard Constraint in AGENTS.md](../../AGENTS.md)), expands to ten with `lwpt agents`. The problem it solves: AI coding harnesses discover a project's commands from its `AGENTS.md`, so downstream repos hand-replicate LWPT's command table there — and every LWPT release silently invalidates those copies. `lwpt agents` makes the binary the source of truth: it writes (or, with `--check`, verifies) a marker-fenced region inside the project's `AGENTS.md` containing every registered subcommand (summary, usage line, per-option help) plus the project's user-declared run-scripts. The region is rendered from the same live `TSubcommandRegistry` that drives `--help` — one registry, two views — so the generated reference cannot drift from the real surface. This follows the pattern the ecosystem converged on in 2025/26: Nx's `configure-ai-agents` writes agent-instruction files from the tool itself, the `agents.md` convention is cross-harness, and self-describing binaries (oclif's `manifest`, cobra's `__complete`, `cargo --list`) are the always-accurate substrate. We chose a tool-written static block over an MCP server or a shipped skill because a static reference in `AGENTS.md` is read by every harness with zero tokens of tool-call overhead and zero runtime — Nx's own retreat to "minimal MCP + skills for command knowledge" is the precedent — and over an `init --agents` flag because verification needs a `--check` mode, and `--check` as an `init` flag would be incoherent for every other `init` mode (the flag-pair awkwardness is what priced in this ADR).

## The region contract

The compat surface consumers may rely on (pinned by `tests/integration/Agents.Test.pas`):

- The region is fenced by `<!-- lwpt:agents:begin -->` and `<!-- lwpt:agents:end -->` on their own lines (marker id derived from `PROGRAM_NAME`). Markers are matched as whole lines only — marker text mid-line is prose — and each may appear at most once. Everything between the markers is machine-written; everything outside is never touched.
- Rendered with LF line endings on every platform, with **no version stamp or timestamp**: regeneration is deterministic, and upgrading the binary alone never invalidates a committed block — `--check` fails only on real drift (surface changed, run-scripts changed, in-region hand edit).
- `--check` re-renders and byte-compares the spliced result; any difference exits 1 and writes nothing. Missing file and missing markers count as stale.
- Missing `AGENTS.md` → a minimal file (heading + region) is created. Existing file without markers → the region is appended after a blank-line separator, with the existing bytes preserved exactly (CRLF prose stays CRLF). A lone, duplicated, or out-of-order marker is a hard error rather than a silent regeneration, because guessing at region boundaries could eat hand-written prose.
- `lwpt.toml` is required: `agents` is project-scoped (it lists the project's run-scripts and writes the project's file). It is offline and touches nothing under `.lwpt/` except the `tmp/` staging used by the atomic write.

## Considered Options

- **Keep the surface at nine; ship generation as `lwpt init --agents`.** No ADR needed. Rejected after the check-mode question: freshness enforcement wants `--check`, and on `init` that flag would apply grammatically to the whole subcommand while meaning something only in `--agents` mode. A dedicated subcommand gives `agents` / `agents --check` the same clean verb–verify pairing as `format` / `format --check`.
- **An MCP server exposing the command surface as tools.** Live and queryable, but a persistent server contradicts the single-binary principle, and the industry data point (Nx trimming its MCP to live-task data while moving command knowledge to static skills) says static docs win for a static surface — cheaper in tokens and available to harnesses without MCP support.
- **A shipped SKILL.md (Turborepo pattern).** Good for workflow knowledge; wrong layer for the command list, which must reflect the *installed* binary version and the *current* project's run-scripts. A skill may still make sense later; the generated block would simply point at it.
- **A machine-readable manifest (`--help --json`, oclif-style).** The substrate pattern, but no harness consumes such manifests today — they all read `AGENTS.md`. The registry iteration added for the generator (`Count`/`Item` on `TSubcommandRegistry`, cli package 0.3.0) keeps this door open; a JSON emitter would be a thin additional view over the same registry.
- **Version-stamping the generated block.** Stricter provenance, rejected: every binary upgrade would flip consumer CI red with zero information content. Drift detection keys off content, not version.

## Consequences

- The frozen-surface Hard Constraint's canonical set becomes `init`, `install`, `add`, `remove`, `build`, `format`, `test`, `repair`, `run`, `agents`; `agents` joins `RESERVED_SUBCOMMAND_NAMES` so an `[agents]` run-script section is a manifest-load error (ADR-0013 rule), and `lwpt run agents` aliases like any other subcommand.
- `TSubcommandRegistry` gains public read iteration (`Count` + `Item`) in the `cli` package (0.2.0 → 0.3.0) with co-located tests; the registry is now explicitly the single source of truth for surface-rendering consumers.
- LWPT dogfoods the mechanism: this repo's own `AGENTS.md` command table is the generated block, and the universal project gate (DEFINITION_OF_DONE.md), the PR workflow, and the Lefthook pre-commit hook (`stage_fixed`) all run `lwpt agents` / `--check`, so the reference in this repo can never go stale.
- `AGENTS.md` joins the atomic-write set: the generator commits through `.lwpt/tmp/` staging with `AtomicWriteBytes` (expanded destination path, per the `AtomicMoveFile` sibling-backup convention).
- The command reference now also contains the `lwpt.toml` structural schema.
  `LWPT.Manifest.Schema` owns immutable section and field records, including
  types, required/default metadata, root-only scope, reserved names, unknown-key
  policy, and the existing per-field malformed-value behavior. Manifest intake
  validates through that registry and the agents renderer iterates it, while
  source syntax, placeholders, cross-field relationships, and other domain
  algorithms remain imperative. A public JSON Schema remains a possible later
  view rather than part of this decision.
