# Testing

How LWPT tests itself: the four-tier policy, the mock HTTP server, the binary-fetch regression that catches the byte-truncation bug, the fixture strategy, and the current test inventory.

## Executive Summary

- **Four tiers** with explicit policy on when each runs: **Unit** (always), **Integration** (always), **E2E** (opt-in `--tier=e2e`; runs in CI's online job), **Manual** (never automatic).
- **E2E crosses a real process or operating-system boundary.** Root CLI tests spawn `./build/lwpt` without `uses LWPT.Core`; package E2E tests use only their package's published API against real operating-system resources.
- **The single most important test** is the HTTPClient binary-fetch regression in `packages/httpclient/source/HTTPClient.Test.pas`. It uses the mock HTTP server (`packages/httpclient/source/Tests.HTTPMockServer.pas`) to inject `#0` bytes into response headers and chunked bodies, deterministically pinning HTTPClient's byte-safe `AppendRawBytes` contract against regression.
- **TestingPascalLibrary is the framework.** Lives in the `testing` workspace package per [ADR-0015](./adr/0015-drop-export-testing-becomes-workspace-package.md) (an earlier embedded-blob model extruded via `lwpt export testing` is retired). Each `*.Test.pas` is a self-contained program; `lwpt test` discovers it, validates a compiler-neutral request, compiles through the FPC driver, retains raw compiler output, stores normalized diagnostics, then runs a successful binary and reads its exit code.
- **Fixtures are committed for small inputs (<100 KB).** Large artefacts are generated at test-run time from a deterministic seed so the repo stays small.
- **Status:** the unit, integration, and E2E inventory is listed below; live `lwpt test` discovery is authoritative. The framework canary (tier-0 — "the testing framework itself works") lives in `packages/testing/source/TestingPascalLibrary.Test.pas`.

## The four tiers

| Tier | Hits network? | Where | Runs in CI on every PR? | Runs in pre-commit hook? |
| --- | --- | --- | --- | --- |
| **Unit** | Never | Co-located in `source/` (`Foo.pas` ↔ `Foo.Test.pas`) | Yes | No |
| **Integration** | Never (mock server + local fixtures) | `tests/integration/` | Yes | No |
| **E2E** | Sometimes (live hosts or loopback only) | `tests/e2e/` and package-owned `tests/e2e/` | Linux leg only (dedicated `pr.yml` step per #102); every platform post-merge via `ci.yml` | No |
| **Manual / spike** | N/A | Anywhere maintainer wants | No | No |

`./build/lwpt test` runs Unit + Integration by default. `./build/lwpt test --tier=e2e` includes the live tier.

## Test programs

Each `*.Test.pas` is a self-contained program:

```pascal
program MyUnit.Test;
{$mode delphi}{$H+}
uses
  TestingPascalLibrary,
  MyUnit;

type
  TMyUnitTests = class(TTestSuite)
  public
    procedure SetupTests; override;
    procedure TestAdds;
  end;

procedure TMyUnitTests.TestAdds;
begin
  Expect<Integer>(MyAdd(2, 2)).ToBe(4);
end;

procedure TMyUnitTests.SetupTests;
begin
  Test('addition works', TestAdds);
end;

begin
  TestRunnerProgram.AddSuite(TMyUnitTests.Create('MyUnit'));
  TestRunnerProgram.Run;
  ExitCode := TestResultToExitCode;
end.
```

`lwpt test`:

1. Discovers every `*.Test.pas` under the manifest's `Units` dirs (plus `.` for the project root) — skipping `.lwpt/`, `build/`, `.git/`.
2. Schedules independent programs concurrently through the machine-wide
   worker budget, compiling each via
   `fpc -Sh -Fu<units> -Fu.lwpt/modules <file> -o<bin>` in its own
   session-private output directory.
3. Runs each successfully compiled binary under the same worker lease and
   reads the exit code (0 = pass; non-zero = fail).
4. Aggregates captured diagnostics in sorted source-path order; exits 1 if
   any failed or any failed to compile.

Concurrency is automatic by default and cannot exceed the shared
`LWPT_WORKER_BUDGET`. `--jobs=N` sets a smaller invocation ceiling;
`--jobs=1` provides a deterministic serial lane. Numeric bail counts both
compiler and runtime failures:

```toml
[test]
bail = 0 # default: run the complete queue
```

`--bail=N` overrides the manifest for one invocation. A positive threshold
stops new scheduling as soon as that many failures have been observed,
terminates and reaps active compiler/test children, and reports the remaining
programs as cancelled. `--bail=0` always runs the complete queue. CI should
use `--bail=1` for fast feedback.

Each `*.Test.pas` file sets its own compiler mode via its include directives. `lwpt test` does **not** force `-M<mode>` — every test file in this codebase ends up in delphi mode (either via an explicit `{$mode delphi}{$H+}` header or via `{$I Shared.inc}`), and forcing a mode would conflict with future workspace-package test files that ship their own directives.

## E2E tests cross a real boundary

Root CLI E2E tests do **not** `uses LWPT.Core`. They spawn `./build/lwpt` as a subprocess and validate via:

- Exit code.
- Parsed stdout / stderr.
- Side-effects on disk (`.lwpt/modules/` contents, lockfile shape, cfg contents, generated binaries).

A typical E2E test:

```pascal
program install_local_diamond.E2E.Test;
{$mode delphi}{$H+}
uses TestingPascalLibrary, SysUtils, Process;

procedure TestInstall;
var
  P: TProcess;
  ExitStatus: Integer;
begin
  SetCurrentDir('tests/e2e/fixtures/diamond/root');
  P := TProcess.Create(nil);
  try
    P.Executable := ExpandFileName('../../../../../build/lwpt');
    P.Parameters.Add('install');
    P.Options := [poWaitOnExit];
    P.Execute;
    ExitStatus := P.ExitStatus;
  finally
    P.Free;
  end;
  Expect<Integer>(ExitStatus).ToBe(0);
  ExpectTrue(FileExists('lwpt.lock'), 'install must write lwpt.lock');
  ExpectTrue(DirectoryExists('.lwpt/modules/leaf-a'),
             'install must extract leaf-a');
end;
```

This catches everything a unit test cannot: CLI parsing, error formatting, exit-code contracts, the cross-platform `TProcess` story, OpenSSL availability, and real path handling. A package-owned E2E test follows the same arm's-length rule: it imports only the package's published units and crosses a real operating-system boundary. The HTTPClient TLS socket E2E therefore drives its public server API through a caller-owned nonblocking loopback socket instead of calling private helpers.

## The binary-fetch regression (the headline test)

The handoff calls out one specific test as the production-readiness gate: the `HTTPClient` byte-fetch regression that pins the byte-safe `AppendRawBytes` accumulator's contract. The original bug it caught was `Copy(PAnsiChar(...))` truncating response bytes at the first `#0` — corrupting binary downloads and poisoning subsequent header / body parsing.

The test must:

- **Deterministically** put `#0` bytes into both response headers and chunked bodies.
- **Force multi-chunk recv splits** so the header-accumulation path's byte handling is exercised at chunk boundaries.
- **Assert the response body's sha256** matches the expected value baked into the test.
- **Fail loudly** if the body is shorter than expected (the truncation symptom).

**Implementation: two complementary paths.**

| Path | Tier | What it catches |
| --- | --- | --- |
| **Mock HTTP server** (`packages/httpclient/source/Tests.HTTPMockServer.pas` binds an ephemeral local port and serves crafted responses with `#0` traps) | Integration | The exact byte-truncation bug, deterministically, on every PR |
| **Pinned real artefact** (fetch a specific tagged release of a small known repo; assert sha256) | E2E | The full network stack end-to-end, including OpenSSL link-time behavior |

Both. The mock server is the regression net; the real artefact is the smoke test.

## Fixture strategy

| Fixture type | Path | Committed? |
| --- | --- | --- |
| Manifest TOML samples | `tests/fixtures/manifests/` | Yes |
| Lockfile samples | `tests/fixtures/lockfiles/` | Yes |
| Diamond-dep local source trees | `tests/fixtures/diamond/{root,a,b,c}/` | Yes |
| Crafted tar archives (incl. >100-byte prefix-split paths, GNU long names, symlinks) | `tests/fixtures/archives/` | Yes |
| Crafted HTTP response bodies (with `#0` traps) | `tests/fixtures/http/` | Yes |
| Large test artefacts (>100 KB) | `tests/fixtures/archives/large/` | **No** — generated at test-run time from a deterministic seed |

The rule: anything ≤ 100 KB is committed; anything larger is seeded. Repo size matters; cleverness in commit messages doesn't.

## Mock HTTP server

`packages/httpclient/source/Tests.HTTPMockServer.pas` exposes `TMockHTTPServer`, which owns an internal `TThread` over raw sockets. Each test acquires its own ephemeral port via `bind(127.0.0.1, 0)`, serves a single configured response template, and dies. Reusable for any future HTTP-layer testing (redirects, content-length lies, chunked edge cases, partial-content responses).

The mock server is **necessary** for the byte-truncation regression — only by controlling the response bytes can you embed `#0` in specific positions. Pinned real artefacts can't deterministically reproduce the pathological case.

## Test inventory

The original backlog is landed and the inventory below tracks the current
test programs. Counts are taken from their registered `Test(...)` cases.

### Landed

| File | Suites / tests | What it asserts |
| --- | --- | --- |
| **`packages/httpclient/source/HTTPClient.Test.pas`** (the headline) | 20 tests in 2 suites | Byte-safe `AppendRawBytes` regression plus response resource bounds. Uses `packages/httpclient/source/Tests.HTTPMockServer.pas` to serve crafted fixed-length, chunked, close-delimited, idle, and slow-drip responses. Pins byte-perfect embedded-`#0` handling; exact-limit and over-limit body/header behavior; strict and duplicate `Content-Length` handling; malformed chunk sizes; fixed-length truncation; and the monotonic whole-request deadline through both response reads and an idle TLS handshake. Includes a 32 KB response that forces multi-recv and exercises the path where header accumulation has already buffered body bytes. |
| **`packages/httpclient/source/TransportSecurity.Test.pas`** | 21 tests in 1 suite | Pins the PKCS#12 memory-BIO server seam: authenticated `Active` state; stable retained-output pointers; internal plaintext retention across `SSL_write` WANT; server-API bounds clamping; empty, UTF-8, embedded-NUL, oversize, garbage, wrong-pass, missing-path, and leaf-plus-intermediate identities; reusable handshakes; plaintext and partial-ciphertext round trips; stale error queues; `SSL_ERROR_SYSCALL`, `SSL_ERROR_ZERO_RETURN`, fatal-handshake, and fatal-shutdown poisoning; graceful `close_notify`; the TLS 1.2 floor; and refused renegotiation. Windows and Unix-not-Darwin run the 20 OpenSSL cases and skip the Darwin stub; Darwin runs the actionable Network.framework stub and records 20 platform skips. The functional OpenSSL cases are pure in-memory and offline. |
| **`packages/cli/source/CLI.Parser.Test.pas`** | 9 tests in 1 suite | Self-spawns in child mode so `ParseCommandLine` consumes real argv. Covers separated valued short options (including hyphen-leading values), opt-in attached values, repeatable `-Fu` / `-d` values, exact-before-longest-prefix matching for multi-character names, missing and unknown short-option errors, unchanged valueless flags, and both existing long-value forms. |
| **`packages/cli/source/CLI.Subcommands.Test.pas`** | 4 tests in 1 suite | In-process coverage of the subcommand registry: `Count`/`Item` iterate in registration order, `Find` resolves case-insensitively to the same object, each subcommand exposes its option objects, and out-of-range `Item` access raises — the registry-side complement to the binary-side `CLIOptions.Test.pas`. |
| **`source/LWPT.BuildRequest.Test.pas`** | 8 tests in 1 suite | Pins canonical versioned TOML serialization, parse round-trips, unsupported-schema failures, ordered extra arguments, compiler-independent target tuples, multi-target compiler capabilities, explicit incompatibility reasons, and normalized diagnostics/artifact/dependency result validation. |
| **`source/LWPT.BuildSession.Test.pas`** | 22 tests in 1 suite | Covers unique private paths, bounded collision-resistant keys, atomic/stale publication, parsed-manifest binding, compiler-argument fingerprinting, implicit, declared, and postbuild-hook input hashing, filesystem-identity publication locks, symlinked workspace inputs, and owner-guarded repair. |
| **`source/LWPT.Command.Build.Test.pas`** | 3 tests in 1 suite | Covers compiler-process cancellation with output capture and child reaping, normal-exit descendant handling, and non-zero exit-code reporting. |
| **`source/LWPT.CompilerDriver.FPC.Test.pas`** | 18 tests in 1 suite | Covers capability-probe caching, target dispatch, timeout cleanup, request compatibility, build/test argument translation, ordered extra-argument forwarding and validation, version failures, stale-artifact classification, structured diagnostics, and Windows executable-path normalization. |
| **`source/LWPT.Core.Test.pas`** | 127 tests in 20 suites | **SHA-256 NIST vectors** (empty, "abc", 56-byte block-boundary pad, 1,000,000 "a" multi-block). **HashTree paths** pin the exact nested-tree digest layout and require slash-separated relative paths on every platform. **LoadManifest happy path / validation / extensions** (bare-string shorthand rejected, strict build-dependency arrays, http source rejected, `[lwpt]`/`[format]`/`[generated]` parsing). **LoadLockfile** (missing / corrupt-TOML / no-schema / v1-migration-hint / empty-table / round-trip-fields). **VerifyAgainstLockfile** (matching graph + lock entries: passes silently; tree-hash mismatch / archive-hash mismatch / orphan manifest dep / stale lockfile entry each raise `EVerifyError` naming the dep + the side that mismatched; local-source with empty archive-hash on both sides is the legitimate happy path and must not false-mismatch). Also covers source/version parsing, git ref parsing, include/exclude pruning, path globs, and custom source prefixes. |
| **`source/LWPT.Formatter.Test.pas`** | 24 tests in 4 suites | Running `lwpt format` twice on the same file is a no-op (the contract `--check` rests on). Plus the canonical shapes that previously broke parameter-rename propagation, scope-expansion coverage, and the `.lwpt/**` default-exclusion/explicit-include precedence contract, including case-sensitive include provenance on filesystems that support case-distinct paths. |
| **`source/LWPT.ManifestEdit.Test.pas`** | 23 tests in 4 suites | Covers dependency insertion, replacement, removal, manifest-line loading, and dependency-name derivation for git-host, local-path, and URL sources. |
| **`source/LWPT.WorkerBudget.Test.pas`** | 21 tests in 1 suite | Self-spawning cross-process coverage for the per-user worker coordinator: two worktree CWDs share a bounded budget, requests are capped, dead owners are reclaimed, live unreadable/malformed/unknown-schema requests fail closed, repeated release/reacquire cannot jump a waiter, and nested LWPT works at budget 1 through one-shot delegation. Delegation coverage refuses fan-out and token reuse, keeps a child counted after parent death, returns capacity after child failure, and prevents parent release from creating a ghost grant. Failed release writes remain retryable, and two scheduler threads safely share one session. Snapshot assertions cover owner identity, granted capacity, lease age, waiting count, and diagnostics. |
| **`packages/semver/source/Semver.Test.pas`** | 12 tests in 3 suites | `Satisfies` happy path (caret/tilde/exact + prerelease exclusion); `RangeIntersects` matrix the resolver leans on (caret+caret across major boundaries, exact+caret, union ranges); `MaxSatisfying` correctness (highest in range, empty when none match, ignore out-of-range). |
| **`packages/testing/source/TestingPascalLibrary.Test.pas`** | 1 test in 1 suite | The framework canary, lives with the package per ADR-0015. Uses TPL at arm's length (one `Expect<Boolean>(True).ToBe(True)`) so that if TPL itself breaks, this file's failure narrows the blame instead of the suite reporting opaquely. Custom exit codes (10/11/12/13/14) for each plausible TPL initialisation failure mode. |
| **`tests/integration/AddRemove.Test.pas`** | 7 tests in 1 suite | Exercises manifest mutation, install-before-write rollback, source-name derivation errors, update-in-place, and remove pruning without following local dependency links. |
| **`tests/integration/BuildClean.Test.pas`** | 4 tests in 1 suite | Covers non-destructive clean behavior, preservation of unrelated files, a missing build directory, and Unix symlink boundaries. |
| **`tests/integration/BuildEntries.Test.pas`** | 13 unconditional tests in 1 suite, plus 1 Unix-only and 1 Darwin-only | Covers named/all-entry selection, fail-fast entry/graph/`--jobs` validation, per-entry compiler-flag forwarding, the Darwin classic-linker path, private entry/mode artifacts, collision-resistant job paths, non-destructive clean behavior, and continuing after per-entry failures. |
| **`tests/integration/InstallLocalDiamond.Test.pas`** | 9 tests in 2 suites | **Full transitive-resolver run** over the canonical diamond graph (root → branch-a + branch-b → leaf-c) with path-syntax local sources (`"../a"`, `"../b"`, `"../c"`) so no network. Asserts lockfile + cfg + tree shape + idempotence + `--frozen` happy path, plus manifest-path invocation from a different cwd. **Tamper detection** — edits a file under `.lwpt/modules/leaf-c/`, runs `--frozen`, asserts `EVerifyError` naming the tree-hash mismatch + the dep; then re-runs install (non-frozen) and confirms `--frozen` succeeds again (the documented recovery). |
| **`tests/integration/ExtractPathological.Test.pas`** | 14 tests in 2 suites | **Pathological ustar shapes** — baseline short path, > 100-char prefix-split, symlink deferred-link pass. **GNU 'L' long-name** — paths > 255 bytes (past ustar's prefix-split ceiling) wrapped in a GNU `'L'` typeflag header + body carrying the real name; the extractor's pending-long-name buffer carries the name across the header boundary. **Failure modes** — missing archive raises `EExtractError`, truncated gzip leaves Dest empty, invalid gzip magic same contract, tar truncated mid-entry never produces a byte-equal file. |
| **`tests/integration/CLIOptions.Test.pas`** | 7 tests in 1 suite | Spawns `./build/lwpt` with various argv. `--help` + `-h` list every subcommand; unknown verb exits non-zero. Option-parsing regression: `build --mode release` (space-separated value) and `build --mode=release` (equals-separated value) must both parse to "release" and produce the same outcome. Invalid `--mode` value exits non-zero. Scratch project (tiny lwpt.toml + one trivial source) built in-test under `build/tests/tmp/cli-options-e2e/`. |
| **`tests/integration/InstallFetchFailure.Test.pas`** | 3 tests in 1 suite | Spawns `lwpt install` against a manifest with a local-path source pointing at a non-existent directory. Exit non-zero, error message names both the dep AND the missing path, and `.lwpt/tmp/` is empty after the failure (no orphans). HTTP-failure variants (HTTP 500 / unreachable port / timeout) require a URL-redirect env-var hook and ship in v1.x. |
| **`tests/integration/Init.Test.pas`** | 21 tests in 1 suite | Spawns fresh and adoption `lwpt init` flows in scratch dirs. Fresh-init coverage asserts manifest + hello-world `.pas` + `.gitignore` artefacts, sanitised `program <ident>;` declarations, no lockfile under `--yes`, a runnable built entry, refuse-to-clobber + `--force` semantics, and `.gitignore` idempotence. Adoption coverage pins byte-for-byte manifest preservation, append-only ignore updates derived from declared build output directories, missing-units directory creation, idempotent found/added reporting, mutually exclusive force, missing/invalid manifests, file-vs-directory conflicts, and refusal to write through external or symlinked paths. |
| **`tests/integration/Hooks.Test.pas`** | 10 tests in 1 suite | Spawns build/test flows against scratch manifests with lifecycle hooks. Covers prebuild/postbuild/pretest execution, private-candidate postbuild context, path-token-safe output retargeting, failed-hook publication refusal, staleness-gated skip behavior, and dep-manifest hook dropping. |
| **`tests/integration/InstallNestedManifest.Test.pas`** | 4 tests in 1 suite | Covers nested dependency-manifest discovery, retained repository prefixes, cfg paths, transitive dependencies, and ambiguous equal-depth fallback. |
| **`tests/integration/InstallSymlinkCycle.Test.pas`** | 3 tests in 1 suite | Pins termination, single manifest discovery, and lockfile hashing when local dependency trees contain directory-symlink cycles. |
| **`tests/integration/Repair.Test.pas`** | 5 tests in 1 suite | Spawns `lwpt repair` in scratch projects. Covers clean no-op behavior, stale install-lock removal, `.lwpt/tmp/` cleanup without touching committed module/archive state, failed build-session reclamation, and dead machine-wide worker-request reclamation with diagnostics. |
| **`tests/integration/Scratch.Test.pas`** | 2 tests in 1 suite | Covers unique invocation-private scratch roots plus reaping of dead-owner roots without deleting live-owner state. |
| **`tests/integration/BuildSessions.Test.pas`** | 12 tests in 1 suite | Uses the test executable as a controllable FPC proxy to cover concurrent sessions, stale publication, parallel ready entries, prerequisite publication ordering, `--jobs=1`, failure isolation, deterministic manifest-order results on Unix and Windows, heartbeat observability, and the fail-closed lost-proxy dispatch guard (redacted environment dump, exit 126). |
| **`tests/integration/Agents.Test.pas`** | 14 tests in 1 suite | Covers the `lwpt agents` command-reference generator: section synthesis from the live subcommand registry, `--check` drift detection, marker preservation, and idempotent regeneration. |
| **`tests/integration/Run.Test.pas`** | 6 tests in 1 suite | Spawns `lwpt run` against scratch projects. Covers user-script execution and exit-code propagation, built-in aliasing with flag passthrough, unknown-script errors, list mode omitting retired `export`, and `export` as an allowed user script name. |
| **`tests/integration/TestScheduling.Test.pas`** | 12 tests in 1 suite | Cross-platform subprocess coverage for default overlap, deterministic `--jobs=1` ordering, `--bail=0` override, compile failures counting toward bail, and the amended bail contract: stop new work, terminate and reap active children, and print sorted diagnostics. |
| **`tests/integration/Version.Test.pas`** | 4 tests in 1 suite | Spawns version-reporting forms and verifies output shape plus drift protection against `lwpt.toml`'s `[package].version`. |

### E2E tier

| File | Suites / tests | What it asserts |
| --- | --- | --- |
| **`tests/e2e/InstallGitHub.E2E.Test.pas`** | 6 tests in 1 suite | Live GitHub fetch of `octocat/Hello-World @ 7fd1a60b…` — the most stable public git ref in existence. Install exits zero, modules tree extracts under `.lwpt/modules/`, archive caches under `.lwpt/archives/<dep>-<ref>.tar.gz`, lockfile records both `archiveHash` and `computedHash`, `--frozen` re-verifies without network, **and** `--frozen` detects an archive byte-tamper (the archive-mismatch path the local-only diamond fixture cannot reach). Honors `LWPT_SKIP_NETWORK=1`. |
| **`tests/e2e/InstallGitLab.E2E.Test.pas`** | 4 tests in 1 suite | Live GitLab fetch of `gitlab-examples/ci-debug-trace @ dd648b2e48ce6518303b0bb580b2ee32fadaf045`. Validates the GitLab archive-URL pattern in `FetchURL`. Same shape as the GitHub suite: install exit / modules dir / lockfile contents / frozen reverify. Honors `LWPT_SKIP_NETWORK=1`. |
| **`tests/e2e/InstallBitbucket.E2E.Test.pas`** | 4 tests in 1 suite | Live Bitbucket fetch of `atlassian/atlaskit @ d7ac1acad54e…`. Validates the Bitbucket archive-URL pattern. Bitbucket strips the top-level dir hash-suffixed; `StripFirstComponent` handles it. Honors `LWPT_SKIP_NETWORK=1`. |
| **`tests/e2e/InstallDirectArchivesWindows.E2E.Test.pas`** | 3 tests in 1 suite | Windows-only live fetch of direct GitHub codeload + GitLab archive URLs through `lwpt install`. Bypasses source-kind URL construction so the suite specifically exercises the SChannel archive-body read path that previously corrupted `SECBUFFER_EXTRA` leftovers. Honors `LWPT_SKIP_NETWORK=1` and self-skips on non-Windows hosts. |
| **`tests/e2e/InstallScript.E2E.Test.pas`** | 11 tests in 2 suites | Unix-only. Runs `scripts/install.sh` end-to-end against the current **latest** published release — no pinned version constant. The test resolves "latest" from GET `/releases/latest` (which returns the newest non-prerelease-flagged release), passes that tag explicitly to the script, and **derives** the expected `--version` from it (binary == tag, per [ADR-0026](./adr/0026-release-version-stamp-from-tag.md)). The script curls the asset, verifies the checksum, extracts, installs; the test asserts the release resolves without a hidden failure, the install exits zero, the binary lands in `INSTALL_DIR` + is executable, and reports the resolved tag. When `GITHUB_TOKEN` is available the resolver authenticates with a Bearer header. A deterministic fake-curl suite covers authenticated success, explicit no-release 404, narrow connectivity skips, distinct primary/secondary rate-limit skips, hard-failing permission/server responses, unclassified curl failure with captured stderr, and empty/malformed successful responses. This is the suite that would have caught the macOS `.zip` regression (asset-name mismatch → 404 against a release we know exists → fail). Honors `LWPT_SKIP_NETWORK=1`; the live smoke self-skips on non-Unix, on clean connect/DNS failure (transient downtime), on a documented GitHub API rate-limit response, and on an explicit `/releases/latest` 404 until the first non-prerelease release exists (prerelease-flagged `rc.x` are covered by `release.yml`'s per-release install-smoke job instead). Other HTTP/API errors, curl failures not classified as connectivity, and parse failures fail hard. |
| **`packages/httpclient/tests/e2e/TransportSecuritySocket.E2E.Test.pas`** | 1 test in 1 suite | Linux-only loopback coverage through the HTTPClient package's public API. A caller-owned nonblocking accepted socket drives accept → fragmented read → short write → graceful close, while the blocking outbound client verifies that stale OpenSSL error-queue entries are cleared before client I/O. Self-skips on non-Linux hosts. |

### Supporting infrastructure

- **`packages/httpclient/source/Tests.HTTPMockServer.pas`** — Unix-only `TThread`-backed single-shot HTTP server. Binds an ephemeral port via `fpSocket`/`fpBind`/`fpListen`/`fpAccept`, serves caller-supplied raw response bytes (no auto-Content-Length, no implicit headers — so pathological shapes are constructible), and dies after one request. Tests can select an initial idle period or byte-at-a-time delayed writes for deadline coverage. Builder helpers include `BuildSimpleResponse(body)` and `BuildChunkedResponse(chunks)`. The Windows path lands when CI hits Windows.
- **`tests/support/Tests.TarSynth.pas`** — minimal POSIX ustar tarball synthesiser. Builders for regular file entries (with automatic prefix-split for > 100-byte paths), symlink entries, directory entries, **and** GNU `'L'` long-name entries via `MakeGnuLongNameRegularFileEntry`. POSIX checksum computed correctly (the eight-spaces convention). `Gzip(plain)` wraps in a gzip stream. Deliberately scoped — no PaxHeader, GNU `'K'` long-linkname not synthesised (extractor handles both via the same pending-long-name buffer), no sparse files.
- **`tests/support/Tests.LwptSubprocess.pas`** — `TProcess` wrapper for the E2E tier. Spawns `./build/lwpt` with given argv, captures stdout + stderr separately (no merge), supports per-test CWD + env-var overrides, honors `LWPT_SKIP_NETWORK=1` (`SkipNetworkTests` helper). The drain loop reads incrementally while the child runs to avoid pipe-buffer deadlock on long outputs. Also exposes `IsNetworkUnavailable(result)` — the narrow connect/DNS-failure detector the live-network suites use to **skip on transient third-party host downtime** (a `Failed to connect to` / `Failed to resolve host` from HTTPClient) while still failing hard on a content/hash/parse mismatch. See [`ci.md`](./ci.md#transient-host-downtime-skips-it-does-not-fail).
- **`tests/support/Tests.Scratch.pas`** — scratch-directory file helpers shared by the integration + E2E test programs: `WriteTextFile` (write a small text file, creating parent dirs) and `RecursiveDelete` (wipe a tree; symlink-aware — links are unlinked, never followed). Replaces the per-test copy-paste of these two helpers.
- **Testable internals exposure** — `SHA256Hex` remains in `LWPT.Core`; `LoadManifest` and manifest model types live in `LWPT.Manifest`; `LoadLockfile`, `VerifyAgainstLockfile`, and `ExtractArchive` live in `LWPT.Install`. Documented as testable-internal surface, not part of the consumer contract.
- **`--tier` flag** on `lwpt test` — default tier runs unit + integration; `--tier=e2e` adds the network-touching tier.
- **Parallel scheduling controls** — `--jobs=N` caps this invocation within
  the shared worker budget. `[test] bail = N` supplies the project default,
  and `--bail=N` overrides it. Compile and runtime failures both count;
  reaching a positive threshold terminates and reaps active children.
- **Test-artefact placement** — every `lwpt test` invocation owns a unique
  `.lwpt/sessions/<session-id>/` directory. Each test program receives a
  private `-FE`, `-FU`, and executable path below that session. Successful
  sessions are removed; failed sessions remain private and diagnosable until
  `lwpt repair` reclaims them.
- **`tests/support/` auto-discovery** — `LWPT.Command.Testing.CmdTest` adds `tests/support` to the FPC `-Fu`/`-Fi` paths automatically when it exists. `LWPT.Command.Format.CmdFormat` does not walk `tests/` implicitly; the root manifest's `[format].include` globs cover `tests/integration/`, `tests/support/`, and `tests/e2e/` explicitly so project-owned test helpers are held to the same formatter rules as `source/` (see [ADR-0007](./adr/0007-formatter-scope-manifest-declared.md)).

### Counts

| Tier | Files | Test cases |
| --- | --- | --- |
| Unit (`source/*.Test.pas` + package self-tests) | 14 | 313 |
| Integration (`tests/integration/*.Test.pas`) | 18 | 152 |
| E2E (`tests/e2e/*.E2E.Test.pas` + package E2E) | 6 | 29 |
| **Total** | **38** | **494** |

### Planned testing work

| Item | Reason | When |
| --- | --- | --- |
| **HTTP-failure tests with test-scoped URL injection** (HTTP 500 / unreachable port / timeout via mock server) | `FetchURL` builds URLs from a hardcoded base prefix per source kind. The fetch-failure contract (`EFetchError` raised, exit ≠ 0, tmp clean) is already covered via the local-source-missing path in `InstallFetchFailure.Test.pas`; deterministic localhost HTTP coverage is tracked in [issue #34](https://github.com/frostney/lwpt/issues/34). | [Issue #34](https://github.com/frostney/lwpt/issues/34) |
| **~~Lockfile records host~~** | **Solved.** The v3 lockfile's `source` field is the verbatim manifest string (`gitlab:org/repo`) and `resolvedURL` is the actual archive URL (`https://gitlab.com/...`). Host is recoverable from either. See ADR-0009. | done |
| **Windows install lock + mock server + subprocess paths** | Install locking is covered through `lwpt install` / `lwpt repair` behavior rather than direct lock-type tests. Native WinSock mock-server regression coverage is tracked in [issue #35](https://github.com/frostney/lwpt/issues/35). | [Issue #35](https://github.com/frostney/lwpt/issues/35) |

## TestingPascalLibrary self-test

LWPT (and every other LWPT-using project) consumes `TestingPascalLibrary` via the `testing` workspace package, then uses it to test everything else. If `TestingPascalLibrary` breaks, none of the project's `*.Test.pas` files can tell us so. Mitigation: the `packages/testing/source/TestingPascalLibrary.Test.pas` canary exercises the framework's basic assertions through a one-test suite with custom exit codes (10/11/12/13/14) for each plausible TPL initialisation failure mode — using TPL itself at arm's length. One file; catches the catastrophe.

**Status:** in place; lives in `packages/testing/` per [ADR-0015](./adr/0015-drop-export-testing-becomes-workspace-package.md).

## Snapshot tests

Out of scope. The formatter's idempotence test catches the same regressions snapshot tests would, with less ceremony.

## Mocking framework

Out of scope. Pascal mocking frameworks (Delphi-Mocks, etc.) are heavyweight and not needed when interface injection or `var`-swap patterns handle every case LWPT has.
